<?php 
	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = "dbtest";

	$connection = mysqli_connect($host,$user,$pass,$db);
?>